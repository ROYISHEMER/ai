import Papa from 'https://cdn.skypack.dev/papaparse';
import brain from 'https://cdn.skypack.dev/brain.js';

document.getElementById('csvFileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    Papa.parse(file, {
        complete: function(results) {
            console.log('CSV data:', results.data);
            const trainingData = results.data.map(row => ({
                input: {
                    na_sales: parseFloat(row['NA_Sales']), 
                    jp_sales: parseFloat(row['JP_Sales']),
                    pal_sales: parseFloat(row['PAL_Sales']),
                    other_sales: parseFloat(row['Other_Sales']),
                    genre: row['Genre'], 
                    console: row['Console'] 
                },
                output: [parseFloat(row['Global_Sales'])]
            }));

            const net = new brain.NeuralNetwork({
                hiddenLayers: [3]
            });

            net.train(trainingData, {
                iterations: 2000,
                errorThresh: 0.005,
                log: details => console.log(details),
                logPeriod: 10
            });

            console.log('Model trained');

            const outputShooterPS4 = net.run({
                na_sales: 5,
                jp_sales: 0.5,
                pal_sales: 3,
                other_sales: 1,
                genre: 'Shooter',
                console: 'PS4'
            });
            console.log('Predicted total sales for Shooter on PS4:', outputShooterPS4);

            const outputActionAdventureX360 = net.run({
                na_sales: 4,
                jp_sales: 1,
                pal_sales: 2.5,
                other_sales: 0.8,
                genre: 'Action-Adventure',
                console: 'X360'
            });
            console.log('Predicted total sales for Action-Adventure on X360:', outputActionAdventureX360);

            const outputActionPS2 = net.run({
                na_sales: 3,
                jp_sales: 2,
                pal_sales: 1,
                other_sales: 0.5,
                genre: 'Action',
                console: 'PS2'
            });
            console.log('Predicted total sales for Action on PS2:', outputActionPS2);

            const outputShooterPS3 = net.run({
                na_sales: 7,
                jp_sales: 0.3,
                pal_sales: 4,
                other_sales: 1.2,
                genre: 'Shooter',
                console: 'PS3'
            });
            console.log('Predicted total sales for Shooter on PS3:', outputShooterPS3);
        }
    });
});
